# Cadrage AgentForge — atelier local

Ce ZIP est un export de spécification, pas un agent généré par IA ni une livraison commerciale.
Aucun paiement, appel de modèle, test du futur agent, RECURSIVE ou BR360 n’a été exécuté pour cet export.
